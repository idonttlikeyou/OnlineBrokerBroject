const chart = document.getElementById("chart");
const ctx = chart.getContext("2d");

let screenHeight = window.innerHeight;
let screenWidth = window.innerWidth;
let clicktimeoutId;
let isdragging = false;
let isholding = false;
let touchX = 0;
let touchY = 0;
let deltaX = 0;
let deltaY = 0;
let positionhitbox = Math.floor(screenHeight*0.02);

let isCrosshairEnabled = false;
let crosshairX = 0;
let crosshairY = 0;

chart.addEventListener("pointerdown", (e) => {
  chart.setPointerCapture(e.pointerId);
  deltaX = 0;
  deltaY = 0;
  touchX = e.clientX;
  touchY = e.clientY;
  console.log("down");
  clickingEvent();
  clicktimeoutId = setTimeout(() => {
    isholding = true;
    holdingEvent();
  }, 100);
});

chart.addEventListener("pointermove", (e) => {
  console.log({
    move: true,
    deltaX,
    deltaY
  });
  deltaX = e.clientX - touchX;
  deltaY = e.clientY - touchY;
  touchX = e.clientX;
  touchY = e.clientY;
  isdragging = true;
  movingEvent();
  clearTimeout(clicktimeoutId);
  console.log("move", e.clientX, e.clientY);
});

chart.addEventListener("pointerup", (e) => {
  clearTimeout(clicktimeoutId);
  if (!isholding && !isdragging) {
    onlyclicking = true;
    isholding = false;
    onlyClickingEvent();
  }
  isholding = false;
  isdragging = false;
  touchX = e.clientX;
  touchY = e.clientY;
  deltaX = 0;
  deltaY = 0;
  unclickEvent();
  console.log("up");
  chart.releasePointerCapture(e.pointerId);
});

function holdingEvent() {
  isCrosshairEnabled = true;
  crosshairX = touchX;
  crosshairY = touchY;
}

function clickingEvent() {
  iscurrentlymovingtp = false;
  iscurrentlymovingsl = false;
  if (Math.abs(touchY - getpositionfromprice(visiblehigh, visiblelow, temptp)) < positionhitbox) {
    iscurrentlymovingtp = true;
  } else if (Math.abs(touchY - getpositionfromprice(visiblehigh, visiblelow, tempsl)) < positionhitbox) {
    iscurrentlymovingsl = true;
  }
}

function movingEvent() {
  crosshairX += deltaX;
  crosshairY += deltaY;
  if (iscurrentlymovingtp) {
    temptp = getpricefromposition(visiblehigh, visiblelow, touchY);
  } else if (iscurrentlymovingsl) {
    tempsl = getpricefromposition(visiblehigh, visiblelow, touchY);
  }
}

function onlyClickingEvent() {
  isCrosshairEnabled = false;
  positionfound = false;
  for (const pos of positions) {
    if (Math.abs(touchY - getpositionfromprice(visiblehigh, visiblelow, pos.open)) < positionhitbox) {
      chosenpositionticket = pos.ticket;
      positionfound = true;
      chosenposition = pos;
      temptp = pos.tp;
      tempsl = pos.sl;
      break;
    }
  }
  if (!positionfound) {
    iscurrentlychoosingtp = false;
    iscurrentlychoosingsl = false;
    temptp = -1;
    tempsl = -1;
  }
}

function unclickEvent() {}

let isConnectedToServer = false;

let ws;
//const ip = "10.254.220.116";
const ip = "192.168.0.109"; // permanent ig
const port = 3000;


// server connection watch
function connect() {
  alertemblem("Connecting to server...");
  ws = new WebSocket(`ws://${ip}:${port}`);

  ws.onopen = () => {
    alertemblem("Connected to server!");
    console.log("CONNECTED");
    isConnectedToServer = true;
    /*ws.send(JSON.stringify({
      type: "ping"
    }));*/
    if (accountpassword != null && accountid != null) {
      login();
    }
  };

  ws.onclose = () => {
    alertemblem("Disconnected from server :(");
    console.log("DISCONNECTED");
    isConnectedToServer = false;
    setTimeout(() => {
      connect();
    }, 3000);
  }

  ws.onerror = () => {
    alertemblem("Failed to reconnect.");
    ws.close();
  }

  ws.onmessage = (e) => {
    const data = JSON.parse(e.data);
    if (data.type === "priceupdate") {
      currentprice = data.currentprice;
      currentopen = data.currentopen;
      currentlow = data.currentlow;
      currenthigh = data.currenthigh;
      currentaskprice = data.askprice;
    } else if (data.type === "ping") {
      console.log(data.message);
      pingedEvent();
    } else if (data.type === "auth_response") {
      if (data.response === "auth_success") {
        authsuccess(data);
      } else {
        authfail();
      }
    } else if (data.type === "historicalpriceupdate") {
      candleIndex = data.candleidx;
      candles = data.data;
      // reset for a moment
      currentprice = currentprice;
      currentopen = currentprice;
      currentlow = currentprice;
      currenthigh = currentprice;
      currentaskprice = currentaskprice;
      //console.log(candles);
    } else if (data.type === "noticeUser") {
      alertemblem(data.message);
    } else if (data.type === "accountUpdate") {
      balance = data.balance;
      margin = data.margin;
      equity = data.equity;
      freemargin = data.freemargin;
      floatingpl = data.floatingpl;
      positions = data.positions;
    }
  };
}
connect();


let accountid;
let accountpassword;
let isAuth = false;
let candles = [];
let currentopen;
let currenthigh;
let currentlow;
let currentprice;

let balance;
let margin;
let equity;
let freemargin;
let floatingpl;

let positions = [];

let chosenpositionticket;
let positionfound = false;
let chosenposition;

let currentaskprice;
let candleIndex;

let totalcandlesinscreen = 10;
let visiblehigh;
let visiblelow;
let candlewidth;

let tempsl = -1;
let temptp = -1;

let iscurrentlychoosingsl = false;
let iscurrentlychoosingtp = false;
let iscurrentlymovingsl = false;
let iscurrentlymovingtp = false;

let pricebarleftposition = 0;

let isOrientationVertical;

let pingstart;
let pingtime;

setTimeout(() => {
  ping();
}, 1000);

function ping() {
  pingstart = performance.now();
  ws.send(JSON.stringify({
    type: "ping"
  }));
}

function pingedEvent() {
  pingtime = performance.now() - pingstart;
}

function orderMenuTP() {
  const pos = chosenposition;
  const a = pos.side === "short"? -0.2 : 0.2;
  if (pos.tp === -1 && temptp === -1) {
    temptp = pos.open + a;
    iscurrentlychoosingtp = true;
  } else {
    temptp = -1;
    iscurrentlychoosingtp = false;
  }
}

function orderMenuSL() {
  const pos = chosenposition;
  const a = pos.side === "short"? 0.2 : -0.2;
  if (pos.sl === -1 && tempsl === -1) {
    tempsl = pos.open + a;
    iscurrentlychoosingsl = true;
  } else {
    tempsl = -1;
    iscurrentlychoosingsl = false;
  }
}

















function updateloop() {
  visiblehigh = currenthigh;
  visiblelow = currentlow;
  ctx.fillStyle = "#000000";
  ctx.fillRect(0, 0, screenWidth, screenHeight);
  if (isAuth) {
    candlewidth = pricebarleftposition/totalcandlesinscreen;
    ctx.beginPath();
    ctx.strokeStyle = "#888888";
    if (isOrientationVertical) {
      ctx.moveTo(pricebarleftposition, 0);
      ctx.lineTo(pricebarleftposition, screenHeight);
    } else {
      ctx.moveTo(pricebarleftposition, 0);
      ctx.lineTo(pricebarleftposition, screenHeight);
    }
    ctx.stroke();

    visiblelow = currentprice;
    let indexingstart = Math.max(0, candles.length - totalcandlesinscreen);
    for (let i = indexingstart; i < candles.length; i++) {
      visiblehigh = Math.max(visiblehigh, candles[i].high);
      visiblelow = Math.min(visiblelow, candles[i].low);
    }
    visiblehigh = Math.max(visiblehigh, currenthigh);
    visiblelow = Math.min(visiblelow, currentlow);

    let leftmostcandleposition = pricebarleftposition - candles.length*candlewidth;

    for (let i = 0; i < candles.length; i++) {
      let candle = candles[i];
      let candleopenpos = getpositionfromprice(visiblehigh, visiblelow, candle.open);
      let candlehighpos = getpositionfromprice(visiblehigh, visiblelow, candle.high);
      let candlelowpos = getpositionfromprice(visiblehigh, visiblelow, candle.low);
      let candleclosepos = getpositionfromprice(visiblehigh, visiblelow, candle.close);
      let candleheight = Math.abs(candleopenpos - candleclosepos);
      let wickheight = Math.abs(candlehighpos - candlelowpos);

      // historical candle
      if (candle.open > candle.close) {
        ctx.fillStyle = "#ff0000";
        ctx.fillRect(leftmostcandleposition+((i-1)*candlewidth), candleopenpos, candlewidth, candleheight);
      } else if (candle.open < candle.close) {
        ctx.fillStyle = "#00ff00";
        ctx.fillRect(leftmostcandleposition+((i-1)*candlewidth), candleclosepos, candlewidth, candleheight);
      } else {
        ctx.fillStyle = "#ffffff";
        ctx.fillRect(leftmostcandleposition+((i-1)*candlewidth), candleclosepos, candlewidth, 1);
      }

      if (candle.open > candle.close) {
        ctx.fillStyle = "#ff0000";
      } else if (candle.open < candle.close) {
        ctx.fillStyle = "#00ff00";
      } else {
        ctx.fillStyle = "#ffffff";
      }
      ctx.fillRect(leftmostcandleposition+((i-1)*candlewidth)+candlewidth/2, candlehighpos, 2, wickheight);
      //document.getElementById("debugtext").textContent = `vis.high: ${visiblehigh}\nvis.low: ${visiblelow}`;
    }
    let currentopenpos = getpositionfromprice(visiblehigh, visiblelow, currentopen);
    let currenthighpos = getpositionfromprice(visiblehigh, visiblelow, currenthigh);
    let currentlowpos = getpositionfromprice(visiblehigh, visiblelow, currentlow);
    let currentclosepos = getpositionfromprice(visiblehigh, visiblelow, currentprice);
    let currentheight = Math.abs(currentopenpos - currentclosepos);
    let currentwickheight = Math.abs(currenthighpos - currentlowpos);

    // current candle
    if (currentopen > currentprice) {
      ctx.fillStyle = "#ff0000";
      ctx.fillRect(pricebarleftposition-candlewidth, currentopenpos, candlewidth, currentheight);
    } else if (currentopen < currentprice) {
      ctx.fillStyle = "#00ff00";
      ctx.fillRect(pricebarleftposition-candlewidth, currentclosepos, candlewidth, currentheight);
    } else {
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(pricebarleftposition-candlewidth, currentclosepos, candlewidth, 1);
    }

    if (currentopen > currentprice) {
      ctx.fillStyle = "#ff0000";
    } else if (currentopen < currentprice) {
      ctx.fillStyle = "#00ff00";
    } else {
      ctx.fillStyle = "#ffffff";
    }
    ctx.fillRect(pricebarleftposition-candlewidth+candlewidth/2, currenthighpos, 2, currentwickheight);

    // UI RENDER
    let priceLabelX = pricebarleftposition;
    let priceLabelY = currentclosepos-(screenWidth-pricebarleftposition)/8;
    let priceLabelW = screenWidth-pricebarleftposition;
    let priceLabelH = (screenWidth-pricebarleftposition)/4;
    let unitedFontSize = Math.floor(priceLabelH-priceLabelH/3);
    // high level
    let chartpricelabelhigh = `Rp.${visiblehigh.toFixed(2)}`;
    ctx.font = `${unitedFontSize}px monospace`;
    let highw = ctx.measureText(chartpricelabelhigh).width;
    ctx.fillStyle = "#ffffff";
    ctx.textBaseline = "top";
    ctx.textAlign = "left";
    ctx.fillText(chartpricelabelhigh, Math.floor(pricebarleftposition + priceLabelW/2 - highw/2), 1);

    // low level
    let chartpricelabellow = `Rp.${visiblelow.toFixed(2)}`;
    ctx.font = `${unitedFontSize}px monospace`;
    let loww = ctx.measureText(chartpricelabellow).width;
    ctx.fillStyle = "#ffffff";
    ctx.textBaseline = "bottom";
    ctx.textAlign = "left";
    ctx.fillText(chartpricelabellow, Math.floor(pricebarleftposition + priceLabelW/2 - loww/2), screenHeight);
    let candlerange = visiblehigh-visiblelow;
    // price level(s)
    // if vertical divide into 12
    if (isOrientationVertical) {
      let eachlabeldiffrence = candlerange/12;
      for (let i = 0; i < 11; i++) {
        let chartpricelabelquarters = `Rp.${(visiblehigh-(eachlabeldiffrence*(i+1))).toFixed(2)}`;
        ctx.font = `${unitedFontSize}px monospace`;
        let quarterw = ctx.measureText(chartpricelabelquarters).width;
        ctx.fillStyle = "#ffffff";
        ctx.textBaseline = "middle";
        ctx.textAlign = "left";
        ctx.fillText(chartpricelabelquarters, Math.floor(pricebarleftposition + priceLabelW/2 - quarterw/2), Math.floor(screenHeight/12 * (i+1)));
      }
    } else /*divide into 6 if horizontal*/ {
      let eachlabeldiffrence = candlerange/6;
      for (let i = 0; i < 5; i++) {
        let chartpricelabelquarters = `Rp.${(visiblehigh-(eachlabeldiffrence*(i+1))).toFixed(2)}`;
        ctx.font = `${unitedFontSize}px monospace`;
        let quarterw = ctx.measureText(chartpricelabelquarters).width;
        ctx.fillStyle = "#ffffff";
        ctx.textBaseline = "middle";
        ctx.textAlign = "left";
        ctx.fillText(chartpricelabelquarters, Math.floor(pricebarleftposition + priceLabelW/2 - quarterw/2), Math.floor(screenHeight/6 * (i+1)));
      }
    }

    // bid
    ctx.fillStyle = "#ff1100";
    ctx.fillRect(priceLabelX, priceLabelY, Math.floor(priceLabelW), Math.floor(priceLabelH));

    let pricetext = `Rp.${Number(currentprice).toFixed(2)}`;
    ctx.font = `${unitedFontSize}px monospace`;
    let priceTextW = ctx.measureText(pricetext).width;
    ctx.fillStyle = "#000000";
    ctx.textBaseline = "middle";
    ctx.textAlign = "left";
    ctx.fillText(pricetext, pricebarleftposition + priceLabelW/2 - priceTextW/2, priceLabelY + priceLabelH/2);

    ctx.strokeStyle = "#ff1100";
    ctx.beginPath();
    ctx.moveTo(0, currentclosepos);
    ctx.lineTo(pricebarleftposition, currentclosepos);
    ctx.stroke();

    //ask
    //console.log(currentaskprice);
    let askLabelY = getpositionfromprice(visiblehigh, visiblelow, currentaskprice)-(screenWidth-pricebarleftposition)/8;
    ctx.fillStyle = "#00ffaa";
    ctx.fillRect(priceLabelX, askLabelY, Math.floor(priceLabelW), Math.floor(priceLabelH));

    let askpricetext = `Rp.${Number(currentaskprice).toFixed(2)}`;
    ctx.font = `${unitedFontSize}px monospace`;
    ctx.fillStyle = "#000000";
    ctx.textBaseline = "middle";
    ctx.textAlign = "left";
    ctx.fillText(askpricetext, pricebarleftposition + priceLabelW/2 - priceTextW/2, askLabelY + priceLabelH/2);

    ctx.strokeStyle = "#00ffaa";
    ctx.beginPath();
    ctx.moveTo(0, getpositionfromprice(visiblehigh, visiblelow, currentaskprice));
    ctx.lineTo(pricebarleftposition, getpositionfromprice(visiblehigh, visiblelow, currentaskprice));
    ctx.stroke();
    for (const pos of positions) {
      if (positionfound && Number(pos.ticket) === Number(chosenpositionticket)) {
        ctx.strokeStyle = pos.side === "short"? "#ff0000": "#00ff00";
      } else if (positionfound) {
        ctx.strokeStyle = "#888888";
      } else {
        ctx.strokeStyle = pos.side === "short"? "#ff0000": "#00ff00";
      }

      ctx.beginPath();
      ctx.moveTo(0, getpositionfromprice(visiblehigh, visiblelow, pos.open));
      ctx.lineTo(pricebarleftposition, getpositionfromprice(visiblehigh, visiblelow, pos.open));
      ctx.stroke();

      let postext = `${pos.side === "short" ? "SELL": "BUY"} ${pos.lot}, ${pos.floatingpl < 0 ? Number(pos.floatingpl).toFixed(2): `+${Number(pos.floatingpl).toFixed(2)}`}`;
      ctx.font = `${unitedFontSize}px monospace`;
      if (positionfound && Number(pos.ticket) === Number(chosenpositionticket)) {
        ctx.fillStyle = pos.side === "short"? "#ff0000": "#00ff00";
      } else if (positionfound) {
        ctx.fillStyle = "#888888";
      } else {
        ctx.fillStyle = pos.side === "short"? "#ff0000": "#00ff00";
      }
      ctx.textBaseline = "bottom";
      ctx.textAlign = "left";
      ctx.fillText(postext, 0, getpositionfromprice(visiblehigh, visiblelow, pos.open));

      if (pos.tp !== -1) {
        ctx.font = `${unitedFontSize}px monospace`;
        if (positionfound) {
          ctx.fillStyle = "#888888";
        } else {
          ctx.fillStyle = pos.side === "short"? "#ff0000": "#00ff00";
        }
        ctx.textBaseline = "bottom";
        ctx.textAlign = "left";
        ctx.fillText("TP", 0, getpositionfromprice(visiblehigh, visiblelow, pos.tp));
      }
      if (pos.sl !== -1) {
        ctx.font = `${unitedFontSize}px monospace`;
        if (positionfound) {
          ctx.fillStyle = "#888888";
        } else {
          ctx.fillStyle = pos.side === "short"? "#ff0000": "#00ff00";
        }
        ctx.textBaseline = "bottom";
        ctx.textAlign = "left";
        ctx.fillText("SL", 0, getpositionfromprice(visiblehigh, visiblelow, pos.sl));
      }
    }

    ctx.strokeStyle = "#00ff00";
    ctx.beginPath();
    ctx.moveTo(0, getpositionfromprice(visiblehigh, visiblelow, temptp));
    ctx.lineTo(pricebarleftposition, getpositionfromprice(visiblehigh, visiblelow, temptp));
    ctx.stroke();
    ctx.fillStyle = "#00ff00";
    ctx.textBaseline = "bottom";
    ctx.textAlign = "left";
    ctx.fillText("TP", 0, getpositionfromprice(visiblehigh, visiblelow, temptp));

    ctx.strokeStyle = "#ff0000";
    ctx.beginPath();
    ctx.moveTo(0, getpositionfromprice(visiblehigh, visiblelow, tempsl));
    ctx.lineTo(pricebarleftposition, getpositionfromprice(visiblehigh, visiblelow, tempsl));
    ctx.stroke();
    ctx.fillStyle = "#ff0000";
    ctx.textBaseline = "bottom";
    ctx.textAlign = "left";
    ctx.fillText("SL", 0, getpositionfromprice(visiblehigh, visiblelow, tempsl));

    //crosshair
    if (isCrosshairEnabled) {
      ctx.strokeStyle = "#ffffff"; // crosshaircolor
      ctx.beginPath();
      ctx.moveTo(0, crosshairY);
      ctx.lineTo(pricebarleftposition, crosshairY);
      ctx.stroke();

      ctx.strokeStyle = "#ffffff"; // crosshaircolor
      ctx.beginPath();
      ctx.moveTo(crosshairX, 0);
      ctx.lineTo(crosshairX, screenHeight);
      ctx.stroke();

      let crosshairLabelY = crosshairY-(screenWidth-pricebarleftposition)/8;
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(priceLabelX, crosshairLabelY, Math.floor(priceLabelW), Math.floor(priceLabelH));
      let crosshairpricetext = `Rp.${getpricefromposition(visiblehigh, visiblelow, crosshairY).toFixed(2)}`;
      ctx.font = `${unitedFontSize}px monospace`;
      ctx.fillStyle = "#000000";
      ctx.textBaseline = "middle";
      ctx.textAlign = "left";
      ctx.fillText(crosshairpricetext, pricebarleftposition + priceLabelW/2 - priceTextW/2, crosshairLabelY + priceLabelH/2);
    }

    document.getElementById("display_margin").textContent = `Margin: ${Number(margin).toFixed(2)}`;
    document.getElementById("display_equity").textContent = `Equity: ${Number(equity).toFixed(2)}`;
    document.getElementById("display_freemargin").textContent = `Free Margin: ${Number(freemargin).toFixed(2)}`;
    document.getElementById("display_floatingpl").textContent = `Floating P/L: ${Number(floatingpl).toFixed(2)}`;

    if (candles) {
      let lastSessionCandleOpen = (candles[candles.length - 1 - (candleIndex%100)]?.open) ?? currentopen;
      const cip = document.getElementById("changeinpercentage");
      const cp = document.getElementById("currentprice");
      const civ = document.getElementById("changeinvalue");
      cip.textContent = currentprice - lastSessionCandleOpen < 0 ? `-${Math.abs(Number(currentprice-lastSessionCandleOpen)/lastSessionCandleOpen*100).toFixed(2)}%`: `+${Number((currentprice-lastSessionCandleOpen)/lastSessionCandleOpen*100).toFixed(2)}%`
      cp.textContent = Number(currentprice).toFixed(2);
      civ.textContent = (currentprice - lastSessionCandleOpen).toFixed(2);

      civ.style.color = currentprice - lastSessionCandleOpen < 0 ? "#ff0000": "#00ff00";
      cip.style.color = currentprice - lastSessionCandleOpen < 0 ? "#ff0000": "#00ff00";
      cp.style.color = currentprice - lastSessionCandleOpen < 0 ? "#ff0000": "#00ff00";
    }

    if (positionfound) {
      let ordertpel = document.getElementById("ordertp");
      if (chosenposition.tp === -1 && !iscurrentlychoosingtp) {
        ordertpel.style.backgroundColor = "#00000000";
        ordertpel.style.color = "#00ff22";
      } else {
        ordertpel.style.backgroundColor = "#00ff22";
        ordertpel.style.color = "#000000";
      }
      let orderslel = document.getElementById("ordersl");
      if (chosenposition.sl === -1 && !iscurrentlychoosingsl) {
        orderslel.style.backgroundColor = "#00000000";
        orderslel.style.color = "#ff0011";
      } else {
        orderslel.style.backgroundColor = "#ff0011";
        orderslel.style.color = "#000000";
      }
    }

  } // isAuth if bracket
  if (positionfound) {
    document.getElementById("ordermenu").style.display = "";
  } else {
    document.getElementById("ordermenu").style.display = "none";
  }


  requestAnimationFrame(updateloop);
}
updateloop();

function getpositionfromprice(visiblehigh, visiblelow, price) {
  return (visiblehigh-price)/(visiblehigh-visiblelow)*screenHeight;
}

function getpricefromposition(visiblehigh, visiblelow, y) {
  return visiblehigh - (y / screenHeight) * (visiblehigh - visiblelow);
}

function authsuccess(data) {
  accountid = document.getElementById("accountid").value;
  accountpassword = document.getElementById("accountpassword").value;
  alert(`Successfully logged on to account '${data.name}'!`)
  isAuth = true;
  document.getElementById("authscreen").style.display = "none";
  document.getElementById("authscreen").style.pointerEvents = "none";
  document.getElementById("authscreenclickblocker").style.display = "none";
  document.getElementById("authscreenclickblocker").style.pointerEvents = "none";
}

function authfail() {
  alert("Failed to authenticate! Please check your password/id!");
}

function login() {
  if (!isConnectedToServer) {
    alert("Error: Cant login now. disconnected from server");
    return;
  }
  const identifier = document.getElementById("accountid").value;
  const pw = document.getElementById("accountpassword").value;
  if (pw == "" || identifier == "") {
    alert("You cant just log on without both id and password... -_-");
  } else {
    ws.send(JSON.stringify({
      type: "authReq",
      id: identifier,
      password: pw
    }));
  }
}


function resize() {
  screenWidth = window.innerWidth;
  screenHeight = window.innerHeight;

  if (screenHeight > screenWidth) {
    isOrientationVertical = true
    pricebarleftposition = screenWidth-screenWidth*0.17;
  } else {
    isOrientationVertical = false;
    pricebarleftposition = screenWidth-screenWidth*0.1;
  }
  const dpr = window.devicePixelRatio || 1;

  chart.style.width = screenWidth + "px";
  chart.style.height = screenHeight + "px";
  chart.width = Math.floor(screenWidth * dpr);
  chart.height = Math.floor(screenHeight * dpr);
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  console.log("resized");
}
window.addEventListener("resize", resize);
resize();

function alertemblem(text) {
  let emblem = document.getElementById("warningemblem");
  let detail = document.getElementById("warningdetail");
  detail.textContent = text;
  emblem.classList.remove("emblemback");
  emblem.classList.add("emblemfall");
  setTimeout(() => {
    emblem.classList.remove("emblemfall");
    emblem.classList.add("emblemback");
  }, 3000);
}

function entry_short() {
  let raw = document.getElementById("order_lot").value;
  let lot = Number(raw);
  lot = Math.round(lot * 100)/100;
  ws.send(JSON.stringify({
    type: "openOrder",
    accid: accountid,
    accpw: accountpassword,
    side: "short",
    lot: lot,
    tp: -1,
    sl: -1
  }));
}

function entry_long() {
  let raw = document.getElementById("order_lot").value;
  let lot = Number(raw);
  lot = Math.round(lot * 100)/100;
  ws.send(JSON.stringify({
    type: "openOrder",
    accid: accountid,
    accpw: accountpassword,
    side: "long",
    lot: lot,
    tp: -1,
    sl: -1
  }));
}

function closeallposition() {
  ws.send(JSON.stringify({
    type: "closeAll",
    accid: accountid,
    accpw: accountpassword
  }));
}