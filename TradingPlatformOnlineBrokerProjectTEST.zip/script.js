const chart = document.getElementById("chart");
const ctx = chart.getContext("2d");

let isConnectedToServer = false;

let ws;
const ip = "192.168.0.100";
const port = 3000;


// server connection watch
function connect() {
  alertemblem("Connecting to server...");
  ws = new WebSocket(`ws://${ip}:${port}`);
  
  ws.onopen = () => {
    alertemblem("Connected to server!");
    console.log("CONNECTED");
    isConnectedToServer = true;
    ws.send(JSON.stringify({type: "ping"}));
  };
  
  ws.onclose = () => {
    alertemblem("Disconnected from server :(");
    console.log("DISCONNECTED");
    isConnectedToServer = false;
    setTimeout(() => {
      connect();
    }, 3000);
  }
  
  ws.onerror = () => {
    alertemblem("Failed to reconnect.");
    ws.close();
  }
  
  ws.onmessage = (e) => {
    console.log(e.data);
    const data = JSON.parse(e.data);
    if(data.type === "priceupdate") {
      console.log("Price Tick:", data.currentprice);
      currentprice = data.currentprice;
      currentopen = data.currentopen;
      currentlow = data.currentlow;
      currenthigh = daat.currenthigh;
    } else if(data.type === "ping") {
      console.log(data.message);
    } else if(data.type === "auth_response") {
      if(data.response === "auth_success") {
        authsuccess(data);
      } else {
        authfail();
      }
    }
  };
}
connect();



let screenHeight = window.innerHeight;
let screenWidth = window.innerWidth;

let accountid;
let accountpassword;
let isAuthenticated = false;
let candles = [];
let currentopen;
let currenthigh;
let currentlow;
let currentprice;

let totalcandlesinscreen = 6;
let visiblehigh;
let visiblelow;

function updateloop() {
  visiblehigh = currenthigh;
  visiblelow = currentlow;
  ctx.fillStyle = "#000000";
  ctx.fillRect(0,0,screenWidth,screenHeight);
  requestAnimationFrame(updateloop);
}
updateloop();

function getpositionfromprice(visiblehigh, visiblelow, price) {
  return Math.round((visiblehigh-price)/(visiblehigh-visiblelow)*screenHeight)
}

function authsuccess(data) {
  accountid = document.getElementById("accountid").value;
  accountpassword = document.getElementById("accountpassword").value;
  alert(`Successfully logged on to account '${data.name}'!`)
  document.getElementById("authscreen").style.display = "none";
}

function authfail() {
  alert("Failed to authenticate! Please check your password/id!");
}

function login() {
  const identifier = document.getElementById("accountid").value;
  const pw = document.getElementById("accountpassword").value;
  if(pw == "" || identifier == "") {
    alert("You cant just log on without either id or password... -_-");
  } else {
    ws.send(JSON.stringify({
      type: "authReq",
      id: identifier,
      password: pw
    }));
  }
}


function resize() {
  screenWidth = window.innerWidth;
  screenHeight = window.innerHeight;
  if(screenHeight > screenWidth) { isOrientationVertical = true
  } else {
    isOrientationVertical = false;
  }
  const dpr = window.devicePixelRatio || 1;
  
  chart.style.width = screenWidth + "px";
  chart.style.height = screenHeight + "px";
  chart.width = Math.floor(screenWidth * dpr);
  chart.height = Math.floor(screenHeight * dpr);
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  console.log("resized");
}
window.addEventListener("resize", resize);
resize();

function alertemblem(text) {
  let emblem = document.getElementById("warningemblem");
  let detail = document.getElementById("warningdetail");
  detail.textContent = text;
  emblem.classList.remove("emblemback");
  emblem.classList.add("emblemfall");
  setTimeout(() => {
    emblem.classList.remove("emblemfall");
    emblem.classList.add("emblemback");
  }, 3000);
}